import tkinter as tk
import tkinter as ttk
from tkinter import messagebox
from PIL import Image, ImageTk
import os
import math
import serial
from serial.tools import list_ports
import struct
from tkinter import ttk
import random
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import datetime
from mode import CommonRateWidgets
from mode import ModeConfigurator
from connection import SerialPortManager
from createconnection import SerialPortGUI
from graph import GraphGUI
from Dashboard import PacemakerPanel
from seriala import PacemakerState
from graph2 import GraphsHandler
# 在程序的开始处定义全局变量

global pacemaker_window
def get_registered_user_count():
    """
    Returns the number of registered users by reading the users.txt file.
    """
    try:
        with open("users.txt", "r") as file:
            return len(file.readlines())
    except FileNotFoundError:
        return 0

import tkinter as tk
from tkinter import ttk

# 假设其他类和函数已经定义

def open_user_dashboard(username):
    global dashboard_window
    close_login_window()
    close_Hello_window()

    dashboard_window = tk.Tk()
    dashboard_window.title(f"Welcome, {username}!")
    dashboard_window.geometry("1600x900")

    # 退出按钮
    back_button = tk.Button(dashboard_window, text="Log out", command=back_to_login, font=("Helvetica", 12))
    back_button.pack(side=tk.TOP, pady=3) 

    # 左侧框架（用于起搏器配置）
    pacemaker_frame = tk.Frame(dashboard_window)
    pacemaker_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # 创建并显示起搏器面板
    pacemaker_panel = PacemakerPanel(pacemaker_frame, username)

    # 右侧框架（用于其他功能）
    right_frame = tk.Frame(dashboard_window, width=800)
    right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

    # 在右侧框架中添加串口连接GUI和图表显示
    serial_port_gui = SerialPortGUI(right_frame)
    graph_gui = GraphsHandler(right_frame, "COM3")

    dashboard_window.mainloop()


# 全局变量
connection_status = PacemakerState.NOT_CONNECTED
save_button = None  # 保存按钮的全局引用

# 处理连接状态变化的函数
def handle_connection_status_change(new_status):
    global connection_status, save_button
    connection_status = new_status
    if save_button:
        if connection_status == PacemakerState.REGISTERED:
            save_button.config(state='normal')
        else:
            save_button.config(state='disabled')







def open_registration_window():
    global registration_window
    registration_window = tk.Tk()
    registration_window.title("Registration")

    # Set the window size
    registration_window.geometry("400x300")

    tk.Label(registration_window, text="Username", font=("Helvetica", 12)).grid(row=0, pady=5, padx=20)
    tk.Label(registration_window, text="Password", font=("Helvetica", 12)).grid(row=1, pady=5, padx=20)
    tk.Label(registration_window, text="Confirm Password", font=("Helvetica", 12)).grid(row=2, pady=5, padx=20)

    username_entry = tk.Entry(registration_window, font=("Helvetica", 12))
    password_entry = tk.Entry(registration_window, show="*", font=("Helvetica", 12))
    confirm_password_entry = tk.Entry(registration_window, show="*", font=("Helvetica", 12))

    username_entry.grid(row=0, column=1, pady=5, padx=20)
    password_entry.grid(row=1, column=1, pady=5, padx=20)
    confirm_password_entry.grid(row=2, column=1, pady=5, padx=20)
   # 设置register
    tk.Button(registration_window, text="Register",
              command=lambda: register_user(username_entry.get(), password_entry.get(), confirm_password_entry.get()),
              font=("Helvetica", 12),
              bg='#4CAF50',  # 设置背景色为绿色
              fg='pink',  # 设置文字颜色为白色
              borderwidth=2,  # 设置边框宽度
              relief="solid"  # 设置边框样式
              ).grid(row=3, column=0, columnspan=2, pady=10)




def open_login_window():
    global login_window
    global root

    root.deiconify()  # Make sure the main root window is visible
    login_window = tk.Toplevel(root)
    login_window.title("Login")

    # Set the window size
    login_window.geometry("400x300")

    tk.Label(login_window, text="Username", font=("Helvetica", 12)).grid(row=0, pady=5, padx=20)
    tk.Label(login_window, text="Password", font=("Helvetica", 12)).grid(row=1, pady=5, padx=20)

    username_entry = tk.Entry(login_window, font=("Helvetica", 12))
    password_entry = tk.Entry(login_window, show="*", font=("Helvetica", 12))

    username_entry.grid(row=0, column=1, pady=5, padx=20)
    password_entry.grid(row=1, column=1, pady=5, padx=20)

    tk.Button(login_window, text="Login", command=lambda: login_user(username_entry.get(), password_entry.get()),
              font=("Helvetica", 12)).grid(row=2, column=0, columnspan=2, pady=10)
    close_Hello_window()


def register_user(username, password, confirm_password):
    if get_registered_user_count() >= 10:
        messagebox.showwarning("Registration Error", "Maximum number of users reached!")
        return

    # Check if username already exists
    try:
        with open("users.txt", "r") as file:
            users = [line.strip().split(",")[0] for line in file.readlines()]
    except FileNotFoundError:
        users = []

    if username in users:
        messagebox.showwarning("Registration Error", "Username already exists. Please choose a different username.")
        return

    if username and password:
        if password == confirm_password:
            with open("users.txt", "a") as file:
                file.write(f"{username},{password}\n")
                
            messagebox.showinfo("Success", "User registered successfully!")
            open_user_dashboard(username)
            close_Hello_window()
        else:
            messagebox.showwarning("Input Error", "Passwords do not match")
    else:
        messagebox.showwarning("Input Error", "Please enter both username and password")



def login_user(username, password):
    try:
        with open("users.txt", "r") as file:
            users = [line.strip().split(",") for line in file.readlines()]

        if [username, password] in users:
            open_user_dashboard(username)
            close_Hello_window()
        else:
            messagebox.showwarning("Login Error", "Invalid username or password")
    except FileNotFoundError:
        messagebox.showwarning("Login Error", "No users registered")








def create_hello_window():
    global hello_window
    global root

    hello_window = tk.Tk()
    hello_window.title("Device Controller-Monitor")
    hello_window.geometry("1100x600")
    hello_window.config(bg='#1A1A2E')
    root = hello_window


   # Top frame with dark gray
    top_frame = tk.Frame(hello_window, bg='#3E3E45', height=2*600//7)
    top_frame.pack(fill='x', side='top')
    
    # Bottom frame with light gray
    bottom_frame = tk.Frame(hello_window, bg='#5B5B5D', height=5*600//7)
    bottom_frame.pack(fill='both', expand=True)

    # Title Label inside top frame
    title_label = tk.Label(top_frame, text="Device Controller-Monitor", font=("Helvetica", 35, "bold"), bg='#3E3E45', fg='white')
    title_label.place(x=1100//2+10, y=40, anchor='center')

    # Team Label inside top frame
    team_label = tk.Label(top_frame, text="SFWRENG 3K04 Lab 1 Team 18", font=("Helvetica", 13), bg='#3E3E45', fg='white')
    team_label.place(x=1100//2+10, y=2*(600//7)//3+30, anchor='center')

    # Login & Register Frame inside bottom frame
    lr_frame = tk.Frame(bottom_frame, bg='#505056', width=800, height=224)
    lr_frame.place(x=1100//2, y=(6*600//14-110), anchor='center')

    # Login Frame (Inside lr_frame)
    login_frame = tk.Frame(lr_frame, bg='#505056', width=390, height=220)
    login_frame.pack(side='left')

    login_label = tk.Label(login_frame, text="Login", font=("Helvetica", 20, "bold"), bg='#505056', fg='white')
    login_label.pack(pady=10)

    username_label = tk.Label(login_frame, text="Username", font=("Helvetica", 12), bg='#505056', fg='white')
    password_label = tk.Label(login_frame, text="Password", font=("Helvetica", 12), bg='#505056', fg='white')
    username_entry = tk.Entry(login_frame, width=30)
    password_entry = tk.Entry(login_frame, width=30, show="*")

    username_label.pack(pady=5)
    username_entry.pack(pady=5)
    password_label.pack(pady=5)
    password_entry.pack(pady=5)

    tk.Button(login_frame, text="Log In",
            width=10, height=2,
            bg='#FFFFFF',
            fg='black',
            borderwidth=0,
            relief="solid",
            command=lambda: login_user(username_entry.get(), password_entry.get()),
            font=("Helvetica", 12)).pack(pady=10)

    # Vertical Line
    line = tk.Canvas(lr_frame, bg='white', width=1, height=110, highlightthickness=0)
    line.pack(side='left', padx=15)

    # Register Frame (Inside lr_frame)
    register_frame = tk.Frame(lr_frame, bg='#505056', width=390, height=220)
    register_frame.pack(side='left')
    register_info = tk.Label(register_frame, text="Register", font=("Helvetica", 20, "bold"), bg='#505056', fg='white')
    register_info.pack(pady=10)
    register_info_label = tk.Label(register_frame, text="Don't have an account?", font=("Helvetica", 12), bg='#505056', fg='white')
    register_info_label.pack(pady=10)

    tk.Button(register_frame, text="Register",
            command=open_registration_window,
            width=20, height=2,
            bg='#FFFFFF',
            fg='black',
            borderwidth=0,
            relief="solid",
            font=("Helvetica", 12)).pack()



    hello_window.mainloop()



def close_login_window():
    try:
        if login_window.winfo_exists():
            login_window.destroy()
    except NameError:
        pass

def close_registration_window():
    try:
        if 'registration_window' in globals() and registration_window.winfo_exists():
            registration_window.destroy()
    except Exception as e:
        print(f"Error closing registration window: {e}")

def close_Hello_window():
    global hello_window
    if hello_window.winfo_exists():
        hello_window.withdraw()  # Hide the window instead of destroying

def close_dashboard_window():
    try:
        if dashboard_window.winfo_exists():
            dashboard_window.destroy()
    except NameError:
        pass

def close_pacemaker_window():
    global pacemaker_window
    try:
        if pacemaker_window.winfo_exists():
            pacemaker_window.destroy()
    except NameError:
        pass

def back_to_login():
    close_dashboard_window()
    create_hello_window()
        







create_hello_window()





