import json
from tkinter import messagebox
from json import JSONDecodeError
from typing import Dict, List, Union

from PyQt5.QtWidgets import QMessageBox, QTableWidget

class ConfigurationHandler:
    _params_per_mode: Dict[str, List[str]]
    _default_params_store: Dict[str, str]
    _user_params_store: Dict[str, str]
    _username: str
    _params_store: Dict[str, Dict[str, str]]
    def __init__(self):
        self._params_store_path = "user_configurations.json"
        self._default_params = self._load_default_params()
        self._user_params = {}

        self._default_params_store = {
            "Lower Rate Limit": '60',
            "Upper Rate Limit": '120',
            "Maximum Sensor Rate": '50',
            "Fixed AV Delay": '150',
            "Atrial Amplitude": '5',
            "Atrial Pulse Width": '1',
            "Atrial Sensitivity": '1',
            "Ventricular Amplitude": '5',
            "Ventricular Pulse Width": '1',
            "Ventricular Sensitivity": '2.5',
            "ARP": '250',
            "VRP": '320',
            "PVARP": '250',
            "Activity Threshold": "Med",
            "Reaction Time": '30',
            "Response Factor": '8',
            "Recovery Time": '5'
        }
        self._params_per_mode = {
            'AOO':  ["Lower Rate Limit", "Upper Rate Limit", "Atrial Amplitude", "Atrial Pulse Width"],
            'VOO':  ["Lower Rate Limit", "Upper Rate Limit", "Ventricular Amplitude", "Ventricular Pulse Width"],
            'AAI':  ["Lower Rate Limit", "Upper Rate Limit", "Atrial Amplitude", "Atrial Pulse Width",
                    "Atrial Sensitivity", "ARP", "PVARP"],
            'VVI':  ["Lower Rate Limit", "Upper Rate Limit", "Ventricular Amplitude", "Ventricular Pulse Width",
                    "Ventricular Sensitivity", "VRP"],
            'AOOR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Atrial Amplitude",
                     "Atrial Pulse Width", "Activity Threshold", "Reaction Time", "Response Factor",
                     "Recovery Time"],
            'VOOR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Ventricular Amplitude",
                     "Ventricular Pulse Width", "Activity Threshold", "Reaction Time", "Response Factor",
                     "Recovery Time"],
            'AAIR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Atrial Amplitude",
                     "Atrial Pulse Width", "Atrial Sensitivity", "ARP", "PVARP", "Activity Threshold", "Reaction Time",
                     "Response Factor", "Recovery Time"],
            'VVIR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Ventricular Amplitude",
                     "Ventricular Pulse Width", "Ventricular Sensitivity", "VRP", "Activity Threshold", "Reaction Time",
                     "Response Factor", "Recovery Time"],
            'DOO':  ["Lower Rate Limit", "Upper Rate Limit", "Fixed AV Delay", "Atrial Amplitude", "Atrial Pulse Width",
                    "Ventricular Amplitude", "Ventricular Pulse Width"],
            'DOOR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Fixed AV Delay",
                     "Atrial Amplitude", "Atrial Pulse Width", "Ventricular Amplitude", "Ventricular Pulse Width",
                     "Activity Threshold", "Reaction Time", "Response Factor", "Recovery Time"]}

        # Create list of values for Activity Threshold
        self._act_thresh = ["V-Low", "Low", "Med-Low", "Med", "Med-High", "High", "V-High"]
        self._user_params_store = {}
        self._username = ""
        self._params_store = {}
        try:
            with open(self._PARAMETERS_FILE_PATH, mode='r') as f:
                self._params_store.update(json.load(f))
        except (FileNotFoundError, JSONDecodeError):
            pass
    def _load_default_params(self):
        # 这里加载默认参数
        return {
            "Lower Rate Limit": '60',
            "Upper Rate Limit": '120',
            "Maximum Sensor Rate": '120',
            "Fixed AV Delay": '150',
            "Atrial Amplitude": '5',
            "Atrial Pulse Width": '1',
            "Atrial Sensitivity": '1',
            "Ventricular Amplitude": '5',
            "Ventricular Pulse Width": '1',
            "Ventricular Sensitivity": '2.5',
            "ARP": '250',
            "VRP": '320',
            "PVARP": '250',
            "Activity Threshold": "Med",
            "Reaction Time": '30',
            "Response Factor": '8',
            "Recovery Time": '5'
        }

    def load_user_params(self, username):
        try:
            with open(self._params_store_path, 'r') as file:
                params_store = json.load(file)
                self._user_params = params_store.get(username, self._default_params)
        except (FileNotFoundError, json.JSONDecodeError):
            self._user_params = self._default_params.copy()

    def save_user_params(self, username, new_params):
        try:
            with open(self._params_store_path, 'r') as file:
                params_store = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            params_store = {}

        params_store[username] = new_params
        with open(self._params_store_path, 'w') as file:
            json.dump(params_store, file)

    def get_params(self):
        return self._user_params

    def reset_to_default(self, username):
        response = messagebox.askyesno("Parameters", "Are you sure you want to reset all the values?")
        if response:
            self.save_user_params(username, self._default_params)
            return True
        return False

    # 其他必要的方法...
