import tkinter as tk
from tkinter import ttk
from mode import CommonRateWidgets
from mode import ModeConfigurator
from seriala import PacemakerState
from seriala import ConnectionHandler

class PacemakerPanel:
    def __init__(self, parent_frame, username):
        self.parent_frame = parent_frame
        self.username = username
        self.mode = tk.StringVar(self.parent_frame)
        
        self.connection_status_label = tk.Label(self.parent_frame, text="Connection Status: Not Connected")
        self.connection_status_label.pack()
        self.connect_button = tk.Button(self.parent_frame, text="Connect to Pacemaker", command=self.connect_pacemaker)
        self.connect_button.pack()
        self._conn = ConnectionHandler(self.update_connection_status)
        self.configurator = ModeConfigurator(self.parent_frame, self.mode.get(), self.update_connection_status)
        self.create_widgets()


    def create_widgets(self):
        tk.Label(self.parent_frame, text="Select Mode:", font=("Helvetica", 12)).pack(pady=10)

        self.mode.set("AOO")  # 设置默认值
        modes = ["AOO", "VOO", "AAI", "VVI", "AOOR", "VOOR", "AAIR", "VVIR"]
        mode_dropdown = tk.OptionMenu(self.parent_frame, self.mode, *modes, command=lambda _: self.configurator.update_widgets(self.mode.get(), self.parent_frame))
        mode_dropdown.pack(pady=10)

        self.configurator.update_widgets(self.mode.get(), self.parent_frame)

        save_button = tk.Button(self.parent_frame, text="Save Configuration",
                                command=lambda: self.configurator.save_configuration(self.username, self.mode.get(), self.configurator.mode_widgets),
                                font=("Helvetica", 12))
        save_button.pack()

        JSON_button = tk.Button(self.parent_frame, text="JSON",
                                command=lambda: self.configurator.save_sort(self.username, self.mode.get(), self.configurator.mode_widgets),
                                font=("Helvetica", 12))
        JSON_button.pack()

    def update_connection_status(self, new_status,message):
        self.connection_status_label.config(text=f"Connection Status: {new_status.name}")
        
    def connect_pacemaker(self):
        if not self.connection_handler:
            # 创建 ConnectionHandler 实例并启动线程
            self.connection_handler = ConnectionHandler(self.update_connection_status)
            self.connection_handler.start()
        else:
            # 这里可以处理重新连接的逻辑，如果需要
            print("Connection handler is already running or needs to be reset.")



