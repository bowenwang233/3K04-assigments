import json
from typing import Dict

class PacemakerConfigHandler:
    def __init__(self):
        self.default_config = self._load_default_config()
        self.user_config = {}
        self.file_path = "pacemaker_config.json"
        self.params_per_mode = self._define_params_per_mode()

    def _load_default_config(self) -> Dict:
        # 定义默认配置
        return {
            "Lower Rate Limit": '60',
            "Upper Rate Limit": '120',
            "Maximum Sensor Rate": '120',
            "Fixed AV Delay": '150',
            "Atrial Amplitude": '5',
            "Atrial Pulse Width": '1',
            "Atrial Sensitivity": '1',
            "Ventricular Amplitude": '5',
            "Ventricular Pulse Width": '1',
            "Ventricular Sensitivity": '2.5',
            "ARP": '250',
            "VRP": '320',
            "PVARP": '250',
            "Activity Threshold": "Med",
            "Reaction Time": '30',
            "Response Factor": '8',
            "Recovery Time": '5'
        }

    def _define_params_per_mode(self) -> Dict:
        # 定义每种模式下的参数
        return {
            'AOO':  ["Lower Rate Limit", "Upper Rate Limit", "Atrial Amplitude", "Atrial Pulse Width"],
            'VOO':  ["Lower Rate Limit", "Upper Rate Limit", "Ventricular Amplitude", "Ventricular Pulse Width"],
            'AAI':  ["Lower Rate Limit", "Upper Rate Limit", "Atrial Amplitude", "Atrial Pulse Width",
                    "Atrial Sensitivity", "ARP", "PVARP"],
            'VVI':  ["Lower Rate Limit", "Upper Rate Limit", "Ventricular Amplitude", "Ventricular Pulse Width",
                    "Ventricular Sensitivity", "VRP"],
            'AOOR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Atrial Amplitude",
                     "Atrial Pulse Width", "Activity Threshold", "Reaction Time", "Response Factor",
                     "Recovery Time"],
            'VOOR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Ventricular Amplitude",
                     "Ventricular Pulse Width", "Activity Threshold", "Reaction Time", "Response Factor",
                     "Recovery Time"],
            'AAIR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Atrial Amplitude",
                     "Atrial Pulse Width", "Atrial Sensitivity", "ARP", "PVARP", "Activity Threshold", "Reaction Time",
                     "Response Factor", "Recovery Time"],
            'VVIR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Ventricular Amplitude",
                     "Ventricular Pulse Width", "Ventricular Sensitivity", "VRP", "Activity Threshold", "Reaction Time",
                     "Response Factor", "Recovery Time"],
            'DOO':  ["Lower Rate Limit", "Upper Rate Limit", "Fixed AV Delay", "Atrial Amplitude", "Atrial Pulse Width",
                    "Ventricular Amplitude", "Ventricular Pulse Width"],
            'DOOR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Fixed AV Delay",
                     "Atrial Amplitude", "Atrial Pulse Width", "Ventricular Amplitude", "Ventricular Pulse Width",
                     "Activity Threshold", "Reaction Time", "Response Factor", "Recovery Time"]
        }

    def save_user_config(self, username: str, params: Dict[str, str]) -> None:
        # 保存用户配置到文件
        self.user_config[username] = params
        with open(self.file_path, 'w') as file:
            json.dump(self.user_config, file)

    def update_user_config(self, username: str, new_params: Dict[str, str]) -> None:
        # 更新用户配置
        self.user_config[username].update(new_params)
        self.save_user_config(username, self.user_config[username])

    def reset_user_config(self, username: str) -> None:
        # 重置用户配置为默认值
        self.user_config[username] = self.default_config
        self.save_user_config(username, self.user_config[username])

    def get_user_config(self, username: str) -> Dict[str, str]:
        # 获取用户配置，如果不存在则创建新的配置
        if username not in self.user_config:
            self.user_config[username] = self.default_config
        return self.user_config[username]

    def filter_params(self, username: str, pace_mode: str) -> Dict[str, str]:
        # 过滤出特定模式下的用户参数
        user_params = self.get_user_config(username)
        mode_params = {key: user_params[key] for key in self.params_per_mode[pace_mode]}
        mode_params["Pacing Mode"] = pace_mode
        return mode_params