import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import datetime

class GraphGUI:
    def __init__(self, master):
        self.master = master
        self.x = []  # 存储时间戳
        self.y = []  # 存储电压值
        self.create_graph()

    def create_graph(self):
        fig = Figure(figsize=(5, 4))
        self.ax = fig.add_subplot(111)
        self.ax.set_xlabel('Time')
        self.ax.set_ylabel('Voltage')

        self.canvas = FigureCanvasTkAgg(fig, master=self.master)
        canvas_widget = self.canvas.get_tk_widget()
        canvas_widget.pack(side=tk.TOP, fill=tk.BOTH, expand=1)

        self.update_graph()

    def update_graph(self):
        now = datetime.datetime.now()
        time_str = now.strftime("%I:%M:%S %p")
        voltage = 0  # 这里可以根据需要更改电压的获取方式

        self.x.append(time_str)
        self.y.append(voltage)

        self.ax.clear()
        self.ax.plot(self.x, self.y)
        self.ax.set_xlabel('Time')
        self.ax.set_ylabel('Voltage')

        N = 8  # 只显示最近的 N 个数据点
        if len(self.x) > N:
            self.ax.set_xlim([self.x[-N], self.x[-1]])

        self.canvas.draw()
        self.master.after(1000, self.update_graph)
