
import tkinter as tk
from json import JSONDecodeError
from typing import Dict, List, Union
from PyQt5.QtWidgets import QMessageBox, QTableWidget
from tkinter import messagebox
from PIL import Image, ImageTk
import os
import json
import tkinter as tk
from tkinter import messagebox
import math
import serial
from serial.tools import list_ports
import struct
from tkinter import ttk
import random
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import datetime
global atrial_sensitivity_value
atrial_sensitivity_value = "0.25"  # 假设默认值
from seriala import ConnectionHandler
from connection import SerialPortManager
from createconnection import SerialPortGUI
global rate_smoothing_value
rate_smoothing_value = "15"
class CommonRateWidgets:
    def __init__(self, master):
        self.master = master
        self.create_widgets()
        self.mode_widgets = []
        
    def create_widgets(self):
        self.lower_rate_limit_label = tk.Label(self.master, text="Lower Rate Limit:", font=("Helvetica", 12))
        self.lower_rate_limit_spinbox = tk.Spinbox(self.master, from_=30, to=175, increment=5, font=("Helvetica", 12), command=self.update_increment)
        self.lower_rate_limit_spinbox.bind('<FocusOut>', self.update_increment)  # Update increment when focus is lost
        self.lower_rate_limit_spinbox.bind('<Return>', self.update_increment)    # Update increment when Enter is pressed

        self.upper_rate_limit_label = tk.Label(self.master, text="Upper Rate Limit:", font=("Helvetica", 12))
        self.upper_rate_limit_spinbox = tk.Spinbox(self.master, from_=50, to=175, increment=5, font=("Helvetica", 12))

   # Atrial Amplitude part
    def Atrial_Amplitude(self):
        self.Atrial_Amplitude_definition()  
        self.Atrial_Amplitude_label.pack(pady=5)
        self.Atrial_Amplitude_spinbox.pack(pady=5)
    
    def Atrial_Amplitude_get(self):
        return [self.Atrial_Amplitude_label, self.Atrial_Amplitude_spinbox]
    
    def Atrial_Amplitude_definition(self):
        self.Atrial_Amplitude_label = tk.Label(self.master, text="Atrial Amplitude:", font=("Helvetica", 12))
        self.Atrial_Amplitude_spinbox = tk.Spinbox(self.master, from_=0.5, to=3.2, increment=0.1, font=("Helvetica", 12))
    # Maximum Sensore Rate
    def Maimum_Sensor_Rate(self):
        self.Maimum_Sensor_Rate_definition()  
        self.Maimum_Sensor_Rate_label.pack(pady=5)
        self.Maimum_Sensor_Rate_spinbox.pack(pady=5)
    
    def Maimum_Sensor_Rate_get(self):
        return [self.Maimum_Sensor_Rate_label, self.Maimum_Sensor_Rate_spinbox]
    
    def Maimum_Sensor_Rate_definition(self):
        self.Maimum_Sensor_Rate_label = tk.Label(self.master, text="Maximum Sensore Rate:", font=("Helvetica", 12))
        self.Maimum_Sensor_Rate_spinbox = tk.Spinbox(self.master, from_=50, to=175, increment=5, font=("Helvetica", 12))
    #Ventricular Amplitude
    def Ventricular_Amplitude(self):
        self.Ventricular_Amplitude_definition()  
        self.Ventricular_Amplitude_label.pack(pady=5)
        self.Ventricular_Amplitude_spinbox.pack(pady=5)
    
    def Ventricular_Amplitude_get(self):
        return [self.Ventricular_Amplitude_label, self.Ventricular_Amplitude_spinbox]
    
    def Ventricular_Amplitude_definition(self):
        self.Ventricular_Amplitude_label = tk.Label(self.master, text="Ventricular Amplitude:", font=("Helvetica", 12))
        self.Ventricular_Amplitude_spinbox = tk.Spinbox(self.master, from_=3.5, to=7.0, increment=0.5, font=("Helvetica", 12))


# Atrial Pulse Width
    def Atrial_Pulse_Width(self):
        self.Atrial_Pulse_Width_label = tk.Label(self.master, text="Atrial Pulse Width:", font=("Helvetica", 12))
        self.Atrial_Pulse_Width_entry = tk.Entry(self.master, font=("Helvetica", 12))
        self.Atrial_Pulse_Width_entry.insert(0, '0.05')  # Insert the fixed value
        self.Atrial_Pulse_Width_entry.config(state='readonly')  # Make it readonly after inserting the value

    def Atrial_Pulse_Width_pack(self):
        self.Atrial_Pulse_Width_label.pack(pady=5)
        self.Atrial_Pulse_Width_entry.pack(pady=5)

    def Atrial_Pulse_Width_get(self):
        return [self.Atrial_Pulse_Width_label, self.Atrial_Pulse_Width_entry]

# Ventricular Pulse Width
    def Ventricular_Pulse_Width(self):
        self.Ventricular_Pulse_Width_definition()  
        self.Ventricular_Pulse_Width_label.pack(pady=5)
        self.Ventricular_Pulse_Width_spinbox.pack(pady=5)
    
    def Ventricular_Pulse_Width_get(self):
        return [self.Ventricular_Pulse_Width_label, self.Ventricular_Pulse_Width_spinbox]
    
    def Ventricular_Pulse_Width_definition(self):
        self.Ventricular_Pulse_Width_label = tk.Label(self.master, text="Ventricular Pulse Width:", font=("Helvetica", 12))
        self.Ventricular_Pulse_Width_spinbox = tk.Spinbox(self.master, from_=0.1, to=1.9, increment=0.1, font=("Helvetica", 12))
#Atrial Sensitivity
    def Atrial_Sensitivity(self):
        self.Atrial_Sensitivity_definition()  
        self.Atrial_Sensitivity_label.pack(pady=5)
        self.Atrial_Sensitivity_optionmenu.pack(pady=5)
        self.Atrial_Sensitivity_var.trace_add("write", self.update_global_variable)
    def update_global_variable(self, *args):
        global atrial_sensitivity_value
        atrial_sensitivity_value = self.Atrial_Sensitivity_var.get()

    def Atrial_Sensitivity_get(self):
        return [self.Atrial_Sensitivity_label, self.Atrial_Sensitivity_optionmenu]

    def Atrial_Sensitivity_definition(self):
        self.Atrial_Sensitivity_label = tk.Label(self.master, text="Atrial Sensitivity:", font=("Helvetica", 12))
        self.Atrial_Sensitivity_var = tk.StringVar(self.master)
        self.Atrial_Sensitivity_var.set("0.25")  
        self.Atrial_Sensitivity_optionmenu = tk.OptionMenu(
            self.master,
            self.Atrial_Sensitivity_var,
            "0.25", "0.5", "0.75"
        )

# rate smoothing 
    def rate_smoothing(self):
        self.rate_smoothing_definition()  
        self.rate_smoothing_label.pack(pady=5)
        self.rate_smoothing_optionmenu.pack(pady=5)
        self.rate_smoothing_var.trace_add("write", self.rate_smoothing_variable)
    def rate_smoothing_variable(self, *args):
        global rate_smoothing_value
        rate_smoothing_value = self.rate_smoothing_var.get()

    def rate_smoothing_get(self):
        return [self.rate_smoothing_label, self.rate_smoothing_optionmenu]

    def rate_smoothing_definition(self):
        self.rate_smoothing_label = tk.Label(self.master, text="rating smoothing:", font=("Helvetica", 12))
        self.rate_smoothing_var = tk.StringVar(self.master)
        self.rate_smoothing_var.set("OFF")  
        self.rate_smoothing_optionmenu = tk.OptionMenu(
            self.master,
            self.rate_smoothing_var,
            "3", "6", "9","15", "18", "21"
        )
#Ventricular Sensitivity
    def Ventricular_Sensitivity(self):
        self.Ventricular_Sensitivity_definition()  
        self.Ventricular_Sensitivity_label.pack(pady=5)
        self.Ventricular_Sensitivity_spinbox.pack(pady=5)
    
    def Ventricular_Sensitivity_get(self):
        return [self.Ventricular_Sensitivity_label, self.Ventricular_Sensitivity_spinbox]
    
    def Ventricular_Sensitivity_definition(self):
        self.Ventricular_Sensitivity_label = tk.Label(self.master, text="Ventricular Sensitivity:", font=("Helvetica", 12))
        self.Ventricular_Sensitivity_spinbox = tk.Spinbox(self.master, from_=1.0, to=10.0, increment=0.5, font=("Helvetica", 12))
#Ventricular Refractory Period
    def Ventricular_Refractory_Period(self):
        self.Ventricular_Refractory_Period_definition()  
        self.Ventricular_Refractory_Period_label.pack(pady=5)
        self.Ventricular_Refractory_Period_spinbox.pack(pady=5)
    
    def Ventricular_Refractory_Period_get(self):
        return [self.Ventricular_Refractory_Period_label, self.Ventricular_Refractory_Period_spinbox]
    
    def Ventricular_Refractory_Period_definition(self):
        self.Ventricular_Refractory_Period_label = tk.Label(self.master, text="VRP:", font=("Helvetica", 12))
        self.Ventricular_Refractory_Period_spinbox = tk.Spinbox(self.master, from_=150, to=500, increment=10, font=("Helvetica", 12))

#Atrial  Refractory Period
    def Atrial_Refractory_Period(self):
        self.Atrial_Refractory_Period_definition()  
        self.Atrial_Refractory_Period_label.pack(pady=5)
        self.Atrial_Refractory_Period_spinbox.pack(pady=5)
    
    def Atrial_Refractory_Period_get(self):
        return [self.Atrial_Refractory_Period_label, self.Atrial_Refractory_Period_spinbox]
    
    def Atrial_Refractory_Period_definition(self):
        self.Atrial_Refractory_Period_label = tk.Label(self.master, text="ARP:", font=("Helvetica", 12))
        self.Atrial_Refractory_Period_spinbox = tk.Spinbox(self.master, from_=150, to=500, increment=10, font=("Helvetica", 12))

#PVARP
    def PVARP(self):
        self.PVARP_definition()  
        self.PVARP_label.pack(pady=5)
        self.PVARP_spinbox.pack(pady=5)
    
    def PVARP_get(self):
        return [self.PVARP_label, self.PVARP_spinbox]
    
    def PVARP_definition(self):
        self.PVARP_label = tk.Label(self.master, text="PVARP:", font=("Helvetica", 12))
        self.PVARP_spinbox = tk.Spinbox(self.master, from_=150, to=500, increment=10, font=("Helvetica", 12))
    def package(self):
        self.reaction_time_label = tk.Label(self.master, text="Reaction Time:", font=("Helvetica", 12))
        self.reaction_time_spinbox = tk.Spinbox(self.master, from_=10, to=50, increment=10, font=("Helvetica", 12) )
        self.response_factor_label = tk.Label(self.master, text="Response Factor:", font=("Helvetica", 12))
        self.response_factor_spinbox = tk.Spinbox(self.master, from_=1, to=16, increment=1, font=("Helvetica", 12) )
        self.recovery_time_label = tk.Label(self.master, text="Recovery Time:", font=("Helvetica", 12))
        self.recovery_time_spinbox = tk.Spinbox(self.master, from_=2, to=16, increment=1, font=("Helvetica", 12) )
    def pack_widgets(self):
        self.lower_rate_limit_label.pack(pady=5)
        self.lower_rate_limit_spinbox.pack(pady=5)
        self.upper_rate_limit_label.pack(pady=5)
        self.upper_rate_limit_spinbox.pack(pady=5)
    def pack_package(self):
        self.package()
        self.reaction_time_label.pack(pady=5)
        self.reaction_time_spinbox.pack(pady=5)
        self.recovery_time_label.pack(pady=5)
        self.recovery_time_spinbox.pack(pady=5)
        self.response_factor_label.pack(pady=5)
        self.response_factor_spinbox.pack(pady=5)

    def get_widgets(self):
        return [self.lower_rate_limit_label, self.lower_rate_limit_spinbox,
                self.upper_rate_limit_label, self.upper_rate_limit_spinbox]
    
    def get_package(self):
        return[self.reaction_time_label,self.reaction_time_spinbox,
               self.recovery_time_label,self.recovery_time_spinbox,
               self.response_factor_label,self.response_factor_spinbox]
    
    def update_increment(self, event=None):
        # Get the current value from the Spinbox and adjust the increment accordingly
        current_value = int(self.lower_rate_limit_spinbox.get())

        if 30 <= current_value < 50:
            increment = 5
        elif 50 <= current_value < 90:
            increment = 1
        elif 90 <= current_value <= 175:
            increment = 5
        else:
            increment = 5  # Default increment

        self.lower_rate_limit_spinbox.config(increment=increment)




class ModeConfigurator:
    _params_per_mode: Dict[str, List[str]]
    _default_params_store: Dict[str, str]
    _user_params_store: Dict[str, str]
    _username: str
    _params_store: Dict[str, Dict[str, str]]
    _PARAMETERS_FILE_PATH = "./parameters.json"
    def __init__(self, master, mode, status_change_callback):
        self.master = master
        self.mode = mode
        pace_mode = self.mode
        self.mode_widgets = []
        self.status_change_callback = status_change_callback
        # 初始化 ConnectionHandler 时使用 status_change_callback
        self._conn = ConnectionHandler(self.status_change_callback)
        self.se = SerialPortManager
        self.trans = SerialPortGUI
        self._default_params_store = {
            "Lower Rate Limit": '60',
            "Upper Rate Limit": '120',
            "Maximum Sensor Rate": '120',
            "Fixed AV Delay": '150',
            "Atrial Amplitude": '1',
            "Atrial Pulse Width": '1',
            "Atrial Sensitivity": '1',
            "Ventricular Amplitude": '5',
            "Ventricular Pulse Width": '1',
            "Ventricular Sensitivity": '2.5',
            "ARP": '250',
            "VRP": '320',
            "PVARP": '250',
            "Activity Threshold": "Med",
            "Reaction Time": '30',
            "Response Factor": '8',
            "Recovery Time": '5',
            "rating smoothing":'3'
        }
        self._params_per_mode = {
            'AOO':  ["Lower Rate Limit", "Upper Rate Limit", "Atrial Amplitude", "Atrial Pulse Width"],
            'VOO':  ["Lower Rate Limit", "Upper Rate Limit", "Ventricular Amplitude", "Ventricular Pulse Width"],
            'AAI':  ["Lower Rate Limit", "Upper Rate Limit", "Atrial Amplitude", "Atrial Pulse Width",
                    "Atrial Sensitivity", "ARP", "PVARP"],
            'VVI':  ["Lower Rate Limit", "Upper Rate Limit", "Ventricular Amplitude", "Ventricular Pulse Width",
                    "Ventricular Sensitivity", "VRP"],
            'AOOR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Atrial Amplitude",
                     "Atrial Pulse Width", "Activity Threshold", "Reaction Time", "Response Factor",
                     "Recovery Time"],
            'VOOR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Ventricular Amplitude",
                     "Ventricular Pulse Width", "Activity Threshold", "Reaction Time", "Response Factor",
                     "Recovery Time"],
            'AAIR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Atrial Amplitude",
                     "Atrial Pulse Width", "Atrial Sensitivity", "ARP", "PVARP", "Activity Threshold", "Reaction Time",
                     "Response Factor", "Recovery Time"],
            'VVIR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Ventricular Amplitude",
                     "Ventricular Pulse Width", "Ventricular Sensitivity", "VRP", "Activity Threshold", "Reaction Time",
                     "Response Factor", "Recovery Time"],
            'DOO':  ["Lower Rate Limit", "Upper Rate Limit", "Fixed AV Delay", "Atrial Amplitude", "Atrial Pulse Width",
                    "Ventricular Amplitude", "Ventricular Pulse Width"],
            'DOOR': ["Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", "Fixed AV Delay",
                     "Atrial Amplitude", "Atrial Pulse Width", "Ventricular Amplitude", "Ventricular Pulse Width",
                     "Activity Threshold", "Reaction Time", "Response Factor", "Recovery Time"]}
        # Create list of values for Activity Threshold
        self._act_thresh = ["V-Low", "Low", "Med-Low", "Med", "Med-High", "High", "V-High"]

        # Dict that stores the parameters for a specific user (stored in username), keys are the parameter name,
        # values are the param value
        self._user_params_store = {}
        self._username = ""

        # Try and optionally load existing parameters from file and update GUI with those saved values
        self._params_store = {}
        try:
            with open(self._PARAMETERS_FILE_PATH, mode='r') as f:
                self._params_store.update(json.load(f))
        except (FileNotFoundError, JSONDecodeError):
            pass

    def clear_widgets(self):
        # Remove all previous mode-specific widgets
        for widget in self.mode_widgets:
            # Check if the object is a widget with a destroy method
            if hasattr(widget, 'destroy'):
                widget.destroy()
        self.mode_widgets.clear()

    def update_widgets(self, selected_mode,pacemaker_window):
        self.clear_widgets()
            # Initial setup
        if selected_mode == "AOO":
                    # Create and pack common rate widgets
                    common_rate_widgets = CommonRateWidgets(self.master)
                    common_rate_widgets.pack_widgets()

                    # Create and pack atrial amplitude widgets
                    AA = CommonRateWidgets(self.master)
                    AA.Atrial_Amplitude()

                    # Create and pack atrial pulse width widgets
                    APW = CommonRateWidgets(self.master)
                    APW.Atrial_Pulse_Width()
                    APW.Atrial_Pulse_Width_pack()

                    # Extend the mode_widgets list with common widgets and specific ones
                    self.mode_widgets.extend(
                        common_rate_widgets.get_widgets() +
                        AA.Atrial_Amplitude_get() +
                        APW.Atrial_Pulse_Width_get()
                    )


        if selected_mode == "VOO":
            common_rate_widgets = CommonRateWidgets(self.master)
            common_rate_widgets.pack_widgets()
            VA = CommonRateWidgets(self.master)
            VA.Ventricular_Amplitude()
            VPW = CommonRateWidgets(self.master)
            VPW.Ventricular_Pulse_Width()

            self.mode_widgets.extend(common_rate_widgets.get_widgets() + VA.Ventricular_Amplitude_get()+VPW.Ventricular_Pulse_Width_get())

        if selected_mode == "AAI":
            common_rate_widgets = CommonRateWidgets(self.master)
            common_rate_widgets.pack_widgets()

            AA = CommonRateWidgets(self.master)
            AA.Atrial_Amplitude()

            APW = CommonRateWidgets(self.master)
            APW.Atrial_Pulse_Width()
            APW.Atrial_Pulse_Width_pack()

            AS = CommonRateWidgets(self.master)
            AS.Atrial_Sensitivity()

            ARP =  CommonRateWidgets(self.master)
            ARP.Atrial_Refractory_Period()

            PVA= CommonRateWidgets(self.master)
            PVA.PVARP()
            lbl6 = tk.Label(pacemaker_window, text="Hysteresis:", font=("Helvetica", 12))
            lbl6.pack(pady=5)
            ent6 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent6.pack(pady=5)

            RS = CommonRateWidgets(self.master)
            RS.rate_smoothing()
            self.mode_widgets.extend(common_rate_widgets.get_widgets() + AA.Atrial_Amplitude_get() +APW.Atrial_Pulse_Width_get()+ AS.Atrial_Sensitivity_get()+ ARP.Atrial_Refractory_Period_get()+PVA.PVARP_get()+RS.rate_smoothing_get()+[lbl6, ent6 ])



        if selected_mode == "VVI":
            common_rate_widgets = CommonRateWidgets(self.master)
            common_rate_widgets.pack_widgets()
            VA = CommonRateWidgets(self.master)
            VA.Ventricular_Amplitude()
            VPW = CommonRateWidgets(self.master)
            VPW.Ventricular_Pulse_Width()
            VS = CommonRateWidgets(self.master)
            VS.Ventricular_Sensitivity()
            VRP = CommonRateWidgets(self.master)
            VRP.Ventricular_Refractory_Period()

            lbl6 = tk.Label(pacemaker_window, text="Hysteresis (ms):", font=("Helvetica", 12))
            lbl6.pack(pady=5)
            ent6 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent6.pack(pady=5)
            RS = CommonRateWidgets(self.master)
            RS.rate_smoothing()
            self.mode_widgets.extend(common_rate_widgets.get_widgets() + VA.Ventricular_Amplitude_get()+VPW.Ventricular_Pulse_Width_get()+VS.Ventricular_Sensitivity_get()+VRP.Ventricular_Refractory_Period_get()+ RS.rate_smoothing_get()+[lbl6, ent6])

        self.master.update()

        if selected_mode == "AOOR":
            common_rate_widgets = CommonRateWidgets(self.master)
            common_rate_widgets.pack_widgets()
            pack = CommonRateWidgets(self.master)
            pack.pack_package()
            AA = CommonRateWidgets(self.master)
            AA.Atrial_Amplitude()
            APW = CommonRateWidgets(self.master)
            APW.Atrial_Pulse_Width()
            APW.Atrial_Pulse_Width_pack()
            MSR= CommonRateWidgets(self.master)
            MSR.Maimum_Sensor_Rate()

            self.mode_widgets.extend(common_rate_widgets.get_widgets() + MSR.Maimum_Sensor_Rate_get()+AA.Atrial_Amplitude_get()+APW.Atrial_Pulse_Width_get()+pack.get_package())

        if selected_mode == "AAIR":
            common_rate_widgets = CommonRateWidgets(self.master)
            common_rate_widgets.pack_widgets()
            pack = CommonRateWidgets(self.master)
            pack.pack_package()
            MSR= CommonRateWidgets(self.master)
            MSR.Maimum_Sensor_Rate()
            AA = CommonRateWidgets(self.master)
            AA.Atrial_Amplitude()
            APW = CommonRateWidgets(self.master)
            APW.Atrial_Pulse_Width()
            APW.Atrial_Pulse_Width_pack()
            AS = CommonRateWidgets(self.master)
            AS.Atrial_Sensitivity()         
            ARP =  CommonRateWidgets(self.master)
            ARP.Atrial_Refractory_Period()
            PVA= CommonRateWidgets(self.master)
            PVA.PVARP()
            RS = CommonRateWidgets(self.master)
            RS.rate_smoothing()
            self.mode_widgets.extend(common_rate_widgets.get_widgets() +RS.rate_smoothing_get()+PVA.PVARP_get()+ARP.Atrial_Refractory_Period_get()+AS.Atrial_Sensitivity_get()+ MSR.Maimum_Sensor_Rate_get()+ pack.get_package()+AA.Atrial_Amplitude_get()+APW.Atrial_Pulse_Width_get())

        if selected_mode == "VOOR":
            common_rate_widgets = CommonRateWidgets(self.master)
            common_rate_widgets.pack_widgets()
            pack = CommonRateWidgets(self.master)
            pack.pack_package()
            self.mode_widgets.extend(common_rate_widgets.get_widgets() + pack.get_package())

        if selected_mode == "VVIR":
            common_rate_widgets = CommonRateWidgets(self.master)
            common_rate_widgets.pack_widgets()
            pack = CommonRateWidgets(self.master)
            pack.pack_package()
            self.mode_widgets.extend(common_rate_widgets.get_widgets() + pack.get_package())
    def save_configuration(self,username, mode, widgets):
        """
        Save the pacemaker configuration for the given user and mode.
        """
        valid = True
        error_messages = []
        # Define the range for each setting
        value_ranges = {
            "Lower Rate Limit": (30, 175),
            "Upper Rate Limit": (50, 175),
            "Atrial Amplitude":(0.5,3.2),
            "Maximum Sensore Rate":(50,175),
            "Ventricular Amplitude":(3.5,7.0),
            "Atrial Pulase Width":(0.05,0.05),
            "Ventricular Pulse Width":(0.1,1.9),
            "Ventricular Sensitivity":(1.0,10.0),
            "VRP":(150,500),
            "ARP":(150,500,),
            "PVARP":(150,500),
            "Reaction Time":(10,50),
            "Response Factor":(1,16),
            "Recovery Time":(2,16)
            # Add other settings and their ranges here
        }

        # Prepare the directory for user data
        user_dir = f"./user_data/{username}"
        os.makedirs(user_dir, exist_ok=True)
        
        # Prepare the mode configuration data
        configuration_data = []

        for i in range(0, len(widgets), 2):  # Assuming label-widget pairs
            label_widget = widgets[i]
            value_widget = widgets[i+1]
            label_text = label_widget.cget("text").replace(":", "").strip()
            # Check if the widget is an instance of StringVar or has a 'get' method
            if isinstance(value_widget, tk.StringVar):
                widget_value = value_widget.get()
            elif hasattr(value_widget, 'get'):
                widget_value = value_widget.get()
            else:
                # If it's neither, print an error message and skip this widget
                print(f"Cannot get value for widget associated with label '{label_text}'")
                continue
            if label_text in value_ranges:
                min_value, max_value = value_ranges[label_text]
                try:
                    value = float(widget_value)  # Use float if the value can be a decimal
                    if not (min_value <= value <= max_value):
                        valid = False
                        error_messages.append(f"{label_text} value '{widget_value}' is out of range ({min_value}-{max_value}).")
                except ValueError:
                    valid = False
                    error_messages.append(f"{label_text} value '{widget_value}' is not a valid number.")
            configuration_data.append(f"{label_text}: {widget_value}")
        
        if mode == "AAI"  and atrial_sensitivity_value is not None:
            configuration_data.append(f"Atrial Sensitivity: {atrial_sensitivity_value}")
        if mode == "AAIR"  and atrial_sensitivity_value is not None:
            configuration_data.append(f"Atrial Sensitivity: {atrial_sensitivity_value}")
        if mode == "AAI" and rate_smoothing_value is not None:
            configuration_data.append(f"rate smoothing : {rate_smoothing_value}")
        if mode == "VVI" and rate_smoothing_value is not None:
            configuration_data.append(f"rate smoothing : {rate_smoothing_value}")
        if mode == "AAIR" and rate_smoothing_value is not None:
            configuration_data.append(f"rate smoothing : {rate_smoothing_value}")
        if mode == "VVIR" and rate_smoothing_value is not None:
            configuration_data.append(f"rate smoothing : {rate_smoothing_value}")

        # Only save the configuration if all values are valid
        if valid:
            sorted_config = self._sort_params(configuration_data)
            mode_file_path = os.path.join(user_dir, f"{mode}.txt")
            with open(mode_file_path, "w") as file:
                for line in configuration_data:
                    file.write(line + "\n")
        else:
            # Show error messages to the user
            messagebox.showerror("Configuration Error", "\n".join(error_messages))

    def save_sort(self, username, mode, widgets):
        # 保存用户输入的配置
        self.save_configuration(username, mode, widgets)
        self.mode = mode
        mode_file_path = os.path.join(f"./user_data/{username}", f"{mode}.txt")
        try:
            # 读取 txt 文件中的配置
            with open(mode_file_path, "r") as file:
                lines = file.readlines()

            # 解析配置数据并更新到 _default_params_store
            for line in lines:
                if ": " in line:
                    label, value = line.strip().split(": ")
                    self._default_params_store[label] = value
                else:
                    print(f"Invalid line format in file: {line}")

            # 保存为 JSON
            params_file_path = "./parameters.json"
            with open(params_file_path, "r+") as file:
                all_user_data = json.load(file)
                all_user_data[username] = self._default_params_store
                file.seek(0)
                json.dump(all_user_data, file, indent=None, separators=(',', ':'))  # 删除缩进，使用紧凑格式
                file.truncate()
            self.update_user_params(username)
            messagebox.showinfo("Configuration Saved", f"Configuration for {mode} mode has been saved successfully.")
            self.transmit_data()
        except (FileNotFoundError, JSONDecodeError, IOError) as error:
            print(f"An error occurred: {error}")

    def _sort_params(self, config_data):
        param_order = [
            "Lower Rate Limit", "Upper Rate Limit", "Maximum Sensor Rate", 
            "Fixed AV Delay", "Atrial Amplitude", "Atrial Pulse Width",
            "Atrial Sensitivity", "Ventricular Amplitude", "Ventricular Pulse Width",
            "Ventricular Sensitivity", "ARP", "VRP", "PVARP", "Activity Threshold",
            "Reaction Time", "Response Factor", "Recovery Time"
        ]
        sorted_config = {param: config_data[param] for param in param_order if param in config_data}
        return sorted_config
    
    def update_user_params(self, username):
        self._username = username
        self._user_params_store = self._params_store.get(username, self._default_params_store)


    def get_params(self, pace_mode: str) -> Dict[str, Union[int, float]]:
        typed_params = {"Pacing Mode": list(self._params_per_mode.keys()).index(pace_mode)}
        for key, value in self._user_params_store.items():
            try:
                typed_params[key] = int(value)
            except:
                try:
                    typed_params[key] = int(float(value) * 20)
                except:
                    typed_params[key] = self._act_thresh.index(value) + 1
        return typed_params

    
    def transmit_data(self):
        print("Transmit data method called") 
        try:
            # 使用 self.mode.get() 获取当前模式的字符串表示
            current_mode = self.mode
            print(f"Current mode: '{current_mode}'")  # 打印当前模式

            if current_mode not in self._params_per_mode:
                raise ValueError(f"Invalid mode: '{current_mode}'")  # 检查模式是否有效

            params_to_send = self.get_params(current_mode)
            paramarray = [12, 5, *[int(params_to_send[key]) for key in self._PARAMS_ORDER]]
            print(f"Parameters to send: {params_to_send}")
            self.trans.connect_to_port(params_to_send)
            messagebox.showinfo("Data Transmission", "Data transmitted successfully to pacemaker.")
        except Exception as e:
            messagebox.showerror("Transmission Error", f"An error occurred during transmission: {e}")
            

