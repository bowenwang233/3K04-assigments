import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import numpy as np
import serial
from struct import unpack
import threading

class GraphsHandler:
    def __init__(self, master, port):
        self.master = master
        self.port = port
        self._conn = serial.Serial(self.port, 115200, timeout=10)
        self._running = True

        # 创建图形和轴
        self.fig, (self.ax_atri, self.ax_vent) = plt.subplots(2, 1, figsize=(5, 4))
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.master)
        self.canvas_widget = self.canvas.get_tk_widget()
        self.canvas_widget.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # 初始化数据
        self._atri_data = np.array([])
        self._vent_data = np.array([])
        self.index = 0
        self.plot_data()
        # 开始读取数据和更新图表
        self.start_reading_data()

    def start_reading_data(self):
        thread = threading.Thread(target=self.read_data_loop)
        thread.daemon = True
        thread.start()

    def read_data_loop(self):
        while self._running:
            if self._conn.in_waiting >= 24:
                data = self._conn.read(24)
                self.process_data(data)

    def process_data(self, data):
        # 解析数据
        unpacked_data = unpack("=HH4BH3BHH3BHBB", data)
        atr_val = unpacked_data[0] / 10000
        vent_val = unpacked_data[1] / 10000

        # 更新图表
        self.update_data(atr_val, vent_val)

    def update_data(self, atr_val, vent_val):
        self._atri_data = np.append(self._atri_data, atr_val)
        self._vent_data = np.append(self._vent_data, vent_val)
        self.index += 1

        # 更新图表的方法
        self.plot_data()

    def plot_data(self):
        # 绘图逻辑
        self.ax_atri.clear()
        self.ax_vent.clear()

        x = np.arange(len(self._atri_data))
        self.ax_atri.plot(x, self._atri_data, label='Atrial')
        self.ax_vent.plot(x, self._vent_data, label='Ventricular')

        self.ax_atri.legend()
        self.ax_vent.legend()
        if self.index > 500:
            self.ax_atri.set_xlim((self.index - 500), self.index)
            self.ax_vent.set_xlim((self.index - 500), self.index)

        self.canvas.draw()

        # 定时更新
        self.master.after(1000, self.plot_data)

