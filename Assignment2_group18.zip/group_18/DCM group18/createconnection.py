import tkinter as tk
from tkinter import ttk, messagebox
from connection import SerialPortManager  # 假设 SerialPortManager 类在 connection 模块中
import serial
import serial.tools.list_ports

class SerialPortGUI:
    def __init__(self, master,data=None):
        self.master = master
        self.data =data 
        self.port_manager = SerialPortManager()
        self.port_var = tk.StringVar(self.master)
        self.create_widgets()

    def create_widgets(self):
        # 创建可用端口的下拉菜单
        available_ports = self.port_manager.get_available_ports()
        if available_ports:
            self.port_var.set(available_ports[0])
        else:
            self.port_var.set("No available ports")

        self.port_dropdown = ttk.Combobox(self.master, textvariable=self.port_var, values=available_ports)
        self.port_dropdown.pack(pady=10)

        # 创建连接按钮
        self.connect_button = tk.Button(self.master, text="Connect", command=self.connect_to_port)
        self.connect_button.pack(pady=10)

    def connect_to_port(self,data=None):
        selected_port = self.port_var.get()
        if selected_port not in self.port_manager.available_ports:
            messagebox.showerror("Error", "No available port selected!")
            return

        if self.port_manager.check_connect(selected_port):
            self.send_data(self, selected_port,data)
            messagebox.showinfo("Success", "Connected successfully!")

        else:
            messagebox.showerror("Error", "Failed to connect.")

    def send_data(self, port_name, data):
        try:
            with serial.Serial(port_name, 115200, timeout=5) as pacemaker:
                pacemaker.write(data)
                # 这里可以添加接收和处理响应的代码
        except serial.SerialException as e:
            print(f"Failed to send data to {port_name}: {str(e)}")

