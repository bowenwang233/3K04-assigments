"""
def check_history(username):
        user_dir = f"./user_data/{username}"
        modes_list = []  # List to store modes

        # Check if the user directory exists
        if os.path.exists(user_dir):
            # List all the mode configuration files for this user
            mode_files = [f for f in os.listdir(user_dir) if f.endswith(".txt")]

            for mode_file in mode_files:
                mode = mode_file.replace(".txt", "")
                modes_list.append(mode)

                mode_file_path = os.path.join(user_dir, mode_file)
                with open(mode_file_path, "r") as file:
                    mode_data = file.readlines()

                # Display mode title
                tk.Label(dashboard_window, text=f"Mode: {mode}", font=("Helvetica", 14, "bold")).pack(pady=10)
                
                # Display mode data with a smaller font
                for line in mode_data:
                    tk.Label(dashboard_window, text=line.strip(), font=("Helvetica", 10)).pack(anchor="w", padx=20)
            
            if not mode_files:
                tk.Label(dashboard_window, text="No mode data found for this user.", font=("Helvetica", 12)).pack(pady=10)
        else:
            tk.Label(dashboard_window, text="No data found for this user.", font=("Helvetica", 12)).pack(pady=10)

        if modes_list:
            tk.Label(dashboard_window, text="Select to send to pacemaker.", font=("Helvetica", 12)).pack(pady=10)
            mode_var = tk.StringVar(dashboard_window)
            mode_var.set(modes_list[0])  # Set default value as the first mode
            mode_dropdown = tk.OptionMenu(dashboard_window, mode_var, *modes_list)
            mode_dropdown.pack(pady=5)
        else:
            tk.Label(dashboard_window, text="No modes found for this user. Please create one.", font=("Helvetica", 12)).pack(pady=10)

    edit_button = tk.Button(dashboard_window, text="check history", command=lambda: [close_dashboard_window(), check_history(username)], font=("Helvetica", 12))
    edit_button.pack(pady=20)
"""
