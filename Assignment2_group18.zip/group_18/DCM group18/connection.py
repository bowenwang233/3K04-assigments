import serial
import serial.tools.list_ports
import struct
from tkinter import messagebox

class SerialPortManager:
    def __init__(self):
        self.available_ports = self.get_available_ports()

    def get_available_ports(self):
        ports = serial.tools.list_ports.comports()
        return [port.name for port in ports]

    def check_connect(self,port_name):
        Start = b'\x16'
        SYNC = b'\x22'
        Signal_echo = Start + SYNC
        i=0
        Signal_echo = Signal_echo + struct.pack("B", 2)
        while(i<71):
            Signal_echo = Signal_echo + struct.pack("B", 0)
            i = i+1
        
        connection = 0
        try:
            with serial.Serial(port_name, 115200, timeout = 5) as pacemaker:
                pacemaker.write(Signal_echo)
                # 如果需要的话，这里可以添加读取和检查响应的代码
                connection = 1
                return connection
        except serial.SerialException as e:
            print(f"Failed to connect to {port_name}: {str(e)}")
            return connection
        
    def send_data(self, port_name, data):
        try:
            with serial.Serial(port_name, 115200, timeout=5) as pacemaker:
                pacemaker.write(data)
                # 这里可以添加接收和处理响应的代码
        except serial.SerialException as e:
            print(f"Failed to send data to {port_name}: {str(e)}")




