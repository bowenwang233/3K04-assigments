import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import os
import math
import serial
from serial.tools import list_ports
import struct
from tkinter import ttk
import random
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import datetime

def close_login_window():
    try:
        if login_window.winfo_exists():
            login_window.destroy()
    except NameError:
        pass

def close_registration_window():
    try:
        if 'registration_window' in globals() and registration_window.winfo_exists():
            registration_window.destroy()
    except Exception as e:
        print(f"Error closing registration window: {e}")

def close_Hello_window():
    global hello_window
    if hello_window.winfo_exists():
        hello_window.withdraw()  # Hide the window instead of destroying

def close_dashboard_window():
    try:
        if dashboard_window.winfo_exists():
            dashboard_window.destroy()
    except NameError:
        pass

def close_pacemaker_window():
    global pacemaker_window
    try:
        if pacemaker_window.winfo_exists():
            pacemaker_window.destroy()
    except NameError:
        pass

def back_to_login():
    close_dashboard_window()
    create_hello_window()
        

def get_registered_user_count():
    """
    Returns the number of registered users by reading the users.txt file.
    """
    try:
        with open("users.txt", "r") as file:
            return len(file.readlines())
    except FileNotFoundError:
        return 0
def get_available_ports():
    ports = serial.tools.list_ports.comports()
    return [port.name for port in ports]

def check_connect(port_name):
    Start = b'\x16'
    SYNC = b'\x22'
    Signal_echo = Start + SYNC
    i=0
    Signal_echo = Signal_echo + struct.pack("B", 2)
    while(i<71):
        Signal_echo = Signal_echo + struct.pack("B", 0)
        i = i+1
    
    connection = 0
    try:
        with serial.Serial(port_name, 115200, timeout = 5) as pacemaker:
            pacemaker.write(Signal_echo)
            # 如果需要的话，这里可以添加读取和检查响应的代码
            connection = 1
            return connection
    except serial.SerialException as e:
        print(f"Failed to connect to {port_name}: {str(e)}")
        return connection



def open_user_dashboard(username):
    global dashboard_window

    close_login_window()

    dashboard_window = tk.Tk()
    dashboard_window.title("User Dashboard")
    dashboard_window.geometry("900x900")

    tk.Label(dashboard_window, text=f"Welcome, {username}!", font=("Helvetica", 16)).pack(pady=20)

    user_dir = f"./user_data/{username}"
    modes_list = []  # List to store modes

    # Check if the user directory exists
    if os.path.exists(user_dir):
        # List all the mode configuration files for this user
        mode_files = [f for f in os.listdir(user_dir) if f.endswith(".txt")]

        for mode_file in mode_files:
            mode = mode_file.replace(".txt", "")
            modes_list.append(mode)

            mode_file_path = os.path.join(user_dir, mode_file)
            with open(mode_file_path, "r") as file:
                mode_data = file.readlines()

            # Display mode title
            tk.Label(dashboard_window, text=f"Mode: {mode}", font=("Helvetica", 14, "bold")).pack(pady=10)
            
            # Display mode data with a smaller font
            for line in mode_data:
                tk.Label(dashboard_window, text=line.strip(), font=("Helvetica", 10)).pack(anchor="w", padx=20)
        
        if not mode_files:
            tk.Label(dashboard_window, text="No mode data found for this user.", font=("Helvetica", 12)).pack(pady=10)
    else:
        tk.Label(dashboard_window, text="No data found for this user.", font=("Helvetica", 12)).pack(pady=10)

    if modes_list:
        tk.Label(dashboard_window, text="Select to send to pacemaker.", font=("Helvetica", 12)).pack(pady=10)
        mode_var = tk.StringVar(dashboard_window)
        mode_var.set(modes_list[0])  # Set default value as the first mode
        mode_dropdown = tk.OptionMenu(dashboard_window, mode_var, *modes_list)
        mode_dropdown.pack(pady=5)
    else:
        tk.Label(dashboard_window, text="No modes found for this user. Please create one.", font=("Helvetica", 12)).pack(pady=10)







    # Add the "Edit Selection" button
    edit_button = tk.Button(dashboard_window, text="Edit Selection", command=lambda: [close_dashboard_window(), open_pacemaker_panel(username)], font=("Helvetica", 12))
    edit_button.pack(pady=20)
    back_button = tk.Button(dashboard_window, text="Log out",
                            command=back_to_login, font=("Helvetica", 12))
    back_button.place(x=2,y=3)

    available_ports = get_available_ports()
    port_var = tk.StringVar(dashboard_window)
    if available_ports:  # 如果有可用的串口，设置默认值为第一个可用的串口
        port_var.set(available_ports[0])
    else:  # 如果没有可用的串口，设置一个占位符
        port_var.set("No available ports")

    port_dropdown = ttk.Combobox(dashboard_window, textvariable=port_var, values=available_ports)
    port_dropdown.pack(pady=10)

    def connect_to_port():
        selected_port = port_var.get()
        if selected_port not in available_ports:
            messagebox.showerror("Error", "No available port selected!")
            return
        if check_connect(selected_port):
            messagebox.showinfo("Success", "Connected successfully!")
        else:
            messagebox.showerror("Error", "Failed to connect.")

    connect_button = tk.Button(dashboard_window, text="Connect", command=connect_to_port)
    connect_button.pack(pady=10)
    x = []  # 存储时间戳
    y = []  # 存储电压值
    
    fig = Figure(figsize=(5, 4))
    ax = fig.add_subplot(111)
    ax.set_xlabel('Time')
    ax.set_ylabel('Voltage')

    canvas = FigureCanvasTkAgg(fig, master=dashboard_window)
    canvas_widget = canvas.get_tk_widget()
    canvas_widget.pack(side=tk.TOP, fill=tk.BOTH, expand=1)
    
    def update_graph():
        now = datetime.datetime.now()
        time_str = now.strftime("%I:%M:%S %p")  # 格式化时间为小时:分钟:秒 AM/PM
        voltage = 0  # 随机生成一个电压值
        
        x.append(time_str)  # 将格式化的时间添加到 x 列表中
        y.append(voltage)  # 将电压值添加到 y 列表中
        
        ax.clear()  # 清除图表上的现有数据
        ax.plot(x, y)  # 绘制新的数据
        ax.set_xlabel('Time')
        ax.set_ylabel('Voltage')
        
        # 如果数据过多，只显示最近的N个数据点
        N = 8  # 你可以根据需要调整这个值
        if len(x) > N:
            ax.set_xlim([x[-N], x[-1]])
        
        canvas.draw()  # 更新图表显示
        dashboard_window.after(1000, update_graph)  # 1秒后再次调用此函数
    
    update_graph()
    dashboard_window.mainloop()




    
def open_pacemaker_panel(username):
    """
    Open a panel for the user to select and configure pacemaker modes.
    """
    global pacemaker_window
    
    close_registration_window()
    close_login_window()
    pacemaker_window = tk.Tk()
    pacemaker_window.title("Pacemaker Configuration Panel")
    pacemaker_window.geometry("400x900")  # Increased height to fit all potential widgets

    # Mode Selection
    tk.Label(pacemaker_window, text="Select Mode:", font=("Helvetica", 12)).pack(pady=10)

    # Using StringVar to hold the value of selected mode
    mode = tk.StringVar(pacemaker_window)
    mode.set("AOO")  # default value

    # Dropdown menu for mode selection
    modes = ["AOO", "VOO", "AAI", "VVI"]
    mode_dropdown = tk.OptionMenu(pacemaker_window, mode, *modes, command=lambda _: update_mode_widgets(mode.get()))
    mode_dropdown.pack(pady=10)

    # Placeholders for mode-specific widgets
    mode_widgets = []

    def update_mode_widgets(selected_mode):
        # Remove all previous mode-specific widgets
        for widget in mode_widgets:
            widget.pack_forget()

        mode_widgets.clear()
            # Initial setup
        if selected_mode == "AOO":
            lbl8 = tk.Label(pacemaker_window, text="Lower Rate Limit (ppm):", font=("Helvetica", 12))
            lbl8.pack(pady=5)
            ent8 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent8.pack(pady=5)

            lbl9 = tk.Label(pacemaker_window, text="Upper Rate Limit(ppm):", font=("Helvetica", 12))
            lbl9.pack(pady=5)
            ent9 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent9.pack(pady=5)
            lbl1 = tk.Label(pacemaker_window, text="Atrial Amplitude(V):", font=("Helvetica", 12))
            lbl1.pack(pady=5)
            ent1 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent1.pack(pady=5)

            lbl2 = tk.Label(pacemaker_window, text="Atrial Pulse Width(ms):", font=("Helvetica", 12))
            lbl2.pack(pady=5)
            ent2 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent2.pack(pady=5)
            mode_widgets.extend([lbl8, ent8, lbl9, ent9])
            mode_widgets.extend([lbl1, ent1, lbl2, ent2])

        if selected_mode == "VOO":
            lbl8 = tk.Label(pacemaker_window, text="Lower Rate Limit (ppm):", font=("Helvetica", 12))
            lbl8.pack(pady=5)
            ent8 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent8.pack(pady=5)

            lbl9 = tk.Label(pacemaker_window, text="Upper Rate Limit(ppm):", font=("Helvetica", 12))
            lbl9.pack(pady=5)
            ent9 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent9.pack(pady=5)

            lbl1 = tk.Label(pacemaker_window, text="Ventricular Amplitude(V):", font=("Helvetica", 12))
            lbl1.pack(pady=5)
            ent1 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent1.pack(pady=5)

            lbl2 = tk.Label(pacemaker_window, text="Ventricular Pulse Width(ms):", font=("Helvetica", 12))
            lbl2.pack(pady=5)
            ent2 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent2.pack(pady=5)
            mode_widgets.extend([lbl8, ent8, lbl9, ent9])
            mode_widgets.extend([lbl1, ent1, lbl2, ent2])

        if selected_mode == "AAI":
            lbl8 = tk.Label(pacemaker_window, text="Lower Rate Limit (ppm):", font=("Helvetica", 12))
            lbl8.pack(pady=5)
            ent8 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent8.pack(pady=5)

            lbl9 = tk.Label(pacemaker_window, text="Upper Rate Limit(ppm):", font=("Helvetica", 12))
            lbl9.pack(pady=5)
            ent9 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent9.pack(pady=5)

            lbl1 = tk.Label(pacemaker_window, text="Atrial Amplitude(V):", font=("Helvetica", 12))
            lbl1.pack(pady=5)
            ent1 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent1.pack(pady=5)

            lbl2 = tk.Label(pacemaker_window, text="Atrial Pulse Width(ms):", font=("Helvetica", 12))
            lbl2.pack(pady=5)
            ent2 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent2.pack(pady=5)

            lbl3 = tk.Label(pacemaker_window, text="Atrial Sensitivity (ms):", font=("Helvetica", 12))
            lbl3.pack(pady=5)
            ent3 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent3.pack(pady=5)

            lbl4 = tk.Label(pacemaker_window, text="ARP (ms):", font=("Helvetica", 12))
            lbl4.pack(pady=5)
            ent4 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent4.pack(pady=5)

            lbl5 = tk.Label(pacemaker_window, text="PVARP (ms):", font=("Helvetica", 12))
            lbl5.pack(pady=5)
            ent5 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent5.pack(pady=5)

            lbl6 = tk.Label(pacemaker_window, text="Hysteresis (ms):", font=("Helvetica", 12))
            lbl6.pack(pady=5)
            ent6 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent6.pack(pady=5)

            lbl7 = tk.Label(pacemaker_window, text="Rate Smoothing  (%):", font=("Helvetica", 12))
            lbl7.pack(pady=5)
            ent7 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent7.pack(pady=5)
            mode_widgets.extend([lbl8, ent8, lbl9, ent9])
            mode_widgets.extend([lbl1, ent1, lbl2, ent2 , lbl3, ent3 , lbl4, ent4 , lbl5, ent5 , lbl6, ent6 , lbl7, ent7])


        if selected_mode == "VVI":
            lbl8 = tk.Label(pacemaker_window, text="Lower Rate Limit (ppm):", font=("Helvetica", 12))
            lbl8.pack(pady=5)
            ent8 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent8.pack(pady=5)

            lbl9 = tk.Label(pacemaker_window, text="Upper Rate Limit(ppm):", font=("Helvetica", 12))
            lbl9.pack(pady=5)
            ent9 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent9.pack(pady=5)

            lbl1 = tk.Label(pacemaker_window, text="Ventricular Amplitude(V):", font=("Helvetica", 12))
            lbl1.pack(pady=5)
            ent1 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent1.pack(pady=5)

            lbl2 = tk.Label(pacemaker_window, text="AVentricular Pulse Width(ms):", font=("Helvetica", 12))
            lbl2.pack(pady=5)
            ent2 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent2.pack(pady=5)

            lbl3 = tk.Label(pacemaker_window, text="Ventricular Sensitivity (ms):", font=("Helvetica", 12))
            lbl3.pack(pady=5)
            ent3 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent3.pack(pady=5)

            lbl4 = tk.Label(pacemaker_window, text="VRP (ms):", font=("Helvetica", 12))
            lbl4.pack(pady=5)
            ent4 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent4.pack(pady=5)

            lbl6 = tk.Label(pacemaker_window, text="Hysteresis (ms):", font=("Helvetica", 12))
            lbl6.pack(pady=5)
            ent6 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent6.pack(pady=5)

            lbl7 = tk.Label(pacemaker_window, text="Rate Smoothing  (%):", font=("Helvetica", 12))
            lbl7.pack(pady=5)
            ent7 = tk.Entry(pacemaker_window, font=("Helvetica", 12))
            ent7.pack(pady=5)
            mode_widgets.extend([lbl8, ent8, lbl9, ent9])
            mode_widgets.extend([lbl1, ent1, lbl2, ent2 , lbl3, ent3 , lbl4, ent4 , lbl6, ent6 , lbl7, ent7])


# 一开始设置默认模式的窗口部件
    update_mode_widgets(mode.get())
    a = tk.Button(pacemaker_window, text="Save Configuration",
          command=lambda: save_configuration(username, mode.get(), mode_widgets),
          font=("Helvetica", 12))
    a.place(x=150,y=800)

    b = tk.Button(pacemaker_window, text = "Back to dashboard",
                  command = lambda:   back_dashboard(username),
                  font=("Helvetica", 12))
    b.place(x=2,y=3)

def back_dashboard(username):
    close_pacemaker_window()
    open_user_dashboard(username)



def save_configuration(username, mode, widgets):
    """
    Save the pacemaker configuration for the given user and mode.
    """
    # Create a directory for the user if it doesn't exist
    user_dir = f"./user_data/{username}"
    if not os.path.exists(user_dir):
        os.makedirs(user_dir)
    
    # Now save the mode configuration
    mode_file_path = os.path.join(user_dir, f"{mode}.txt")
    with open(mode_file_path, "w") as file:
        for i in range(0, len(widgets), 2):  # Step by 2 since we have label, entry pairs
            label = widgets[i].cget("text")
            entry = widgets[i+1].get()
            file.write(f"{label}: {entry}\n")
    close_pacemaker_window()
    open_user_dashboard(username)



def open_registration_window():
    global registration_window
    registration_window = tk.Tk()
    registration_window.title("Registration")

    # Set the window size
    registration_window.geometry("400x300")

    tk.Label(registration_window, text="Username", font=("Helvetica", 12)).grid(row=0, pady=5, padx=20)
    tk.Label(registration_window, text="Password", font=("Helvetica", 12)).grid(row=1, pady=5, padx=20)
    tk.Label(registration_window, text="Confirm Password", font=("Helvetica", 12)).grid(row=2, pady=5, padx=20)

    username_entry = tk.Entry(registration_window, font=("Helvetica", 12))
    password_entry = tk.Entry(registration_window, show="*", font=("Helvetica", 12))
    confirm_password_entry = tk.Entry(registration_window, show="*", font=("Helvetica", 12))

    username_entry.grid(row=0, column=1, pady=5, padx=20)
    password_entry.grid(row=1, column=1, pady=5, padx=20)
    confirm_password_entry.grid(row=2, column=1, pady=5, padx=20)
   # 设置register
    tk.Button(registration_window, text="Register",
              command=lambda: register_user(username_entry.get(), password_entry.get(), confirm_password_entry.get()),
              font=("Helvetica", 12),
              bg='#4CAF50',  # 设置背景色为绿色
              fg='pink',  # 设置文字颜色为白色
              borderwidth=2,  # 设置边框宽度
              relief="solid"  # 设置边框样式
              ).grid(row=3, column=0, columnspan=2, pady=10)




def open_login_window():
    global login_window
    global root

    root.deiconify()  # Make sure the main root window is visible
    login_window = tk.Toplevel(root)
    login_window.title("Login")

    # Set the window size
    login_window.geometry("400x300")

    tk.Label(login_window, text="Username", font=("Helvetica", 12)).grid(row=0, pady=5, padx=20)
    tk.Label(login_window, text="Password", font=("Helvetica", 12)).grid(row=1, pady=5, padx=20)

    username_entry = tk.Entry(login_window, font=("Helvetica", 12))
    password_entry = tk.Entry(login_window, show="*", font=("Helvetica", 12))

    username_entry.grid(row=0, column=1, pady=5, padx=20)
    password_entry.grid(row=1, column=1, pady=5, padx=20)

    tk.Button(login_window, text="Login", command=lambda: login_user(username_entry.get(), password_entry.get()),
              font=("Helvetica", 12)).grid(row=2, column=0, columnspan=2, pady=10)
    close_Hello_window()


def register_user(username, password, confirm_password):
    if get_registered_user_count() >= 10:
        messagebox.showwarning("Registration Error", "Maximum number of users reached!")
        return

    # Check if username already exists
    try:
        with open("users.txt", "r") as file:
            users = [line.strip().split(",")[0] for line in file.readlines()]
    except FileNotFoundError:
        users = []

    if username in users:
        messagebox.showwarning("Registration Error", "Username already exists. Please choose a different username.")
        return

    if username and password:
        if password == confirm_password:
            with open("users.txt", "a") as file:
                file.write(f"{username},{password}\n")
                
            messagebox.showinfo("Success", "User registered successfully!")
            open_pacemaker_panel(username)  # Open the pacemaker panel upon successful registration
            close_Hello_window()
        else:
            messagebox.showwarning("Input Error", "Passwords do not match")
    else:
        messagebox.showwarning("Input Error", "Please enter both username and password")



def login_user(username, password):
    try:
        with open("users.txt", "r") as file:
            users = [line.strip().split(",") for line in file.readlines()]

        if [username, password] in users:
            open_user_dashboard(username)
            close_Hello_window()
        else:
            messagebox.showwarning("Login Error", "Invalid username or password")
    except FileNotFoundError:
        messagebox.showwarning("Login Error", "No users registered")








def create_hello_window():
    global hello_window
    global root

    hello_window = tk.Tk()
    hello_window.title("Device Controller-Monitor")
    hello_window.geometry("1100x600")
    hello_window.config(bg='#1A1A2E')
    root = hello_window


   # Top frame with dark gray
    top_frame = tk.Frame(hello_window, bg='#3E3E45', height=2*600//7)
    top_frame.pack(fill='x', side='top')
    
    # Bottom frame with light gray
    bottom_frame = tk.Frame(hello_window, bg='#5B5B5D', height=5*600//7)
    bottom_frame.pack(fill='both', expand=True)

    # Title Label inside top frame
    title_label = tk.Label(top_frame, text="Device Controller-Monitor", font=("Helvetica", 35, "bold"), bg='#3E3E45', fg='white')
    title_label.place(x=1100//2+10, y=40, anchor='center')

    # Team Label inside top frame
    team_label = tk.Label(top_frame, text="SFWRENG 3K04 Lab 1 Team 18", font=("Helvetica", 13), bg='#3E3E45', fg='white')
    team_label.place(x=1100//2+10, y=2*(600//7)//3+30, anchor='center')

    # Login & Register Frame inside bottom frame
    lr_frame = tk.Frame(bottom_frame, bg='#505056', width=800, height=224)
    lr_frame.place(x=1100//2, y=(6*600//14-110), anchor='center')

    # Login Frame (Inside lr_frame)
    login_frame = tk.Frame(lr_frame, bg='#505056', width=390, height=220)
    login_frame.pack(side='left')

    login_label = tk.Label(login_frame, text="Login", font=("Helvetica", 20, "bold"), bg='#505056', fg='white')
    login_label.pack(pady=10)

    username_label = tk.Label(login_frame, text="Username", font=("Helvetica", 12), bg='#505056', fg='white')
    password_label = tk.Label(login_frame, text="Password", font=("Helvetica", 12), bg='#505056', fg='white')
    username_entry = tk.Entry(login_frame, width=30)
    password_entry = tk.Entry(login_frame, width=30, show="*")

    username_label.pack(pady=5)
    username_entry.pack(pady=5)
    password_label.pack(pady=5)
    password_entry.pack(pady=5)

    tk.Button(login_frame, text="Log In",
            width=10, height=2,
            bg='#FFFFFF',
            fg='black',
            borderwidth=0,
            relief="solid",
            command=lambda: login_user(username_entry.get(), password_entry.get()),
            font=("Helvetica", 12)).pack(pady=10)

    # Vertical Line
    line = tk.Canvas(lr_frame, bg='white', width=1, height=110, highlightthickness=0)
    line.pack(side='left', padx=15)

    # Register Frame (Inside lr_frame)
    register_frame = tk.Frame(lr_frame, bg='#505056', width=390, height=220)
    register_frame.pack(side='left')
    register_info = tk.Label(register_frame, text="Register", font=("Helvetica", 20, "bold"), bg='#505056', fg='white')
    register_info.pack(pady=10)
    register_info_label = tk.Label(register_frame, text="Don't have an account?", font=("Helvetica", 12), bg='#505056', fg='white')
    register_info_label.pack(pady=10)

    tk.Button(register_frame, text="Register",
            command=open_registration_window,
            width=20, height=2,
            bg='#FFFFFF',
            fg='black',
            borderwidth=0,
            relief="solid",
            font=("Helvetica", 12)).pack()



    hello_window.mainloop()

create_hello_window()





